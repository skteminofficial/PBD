# Changelog

## v2.1.5 — Sprint 1.5 Core Framework

- Memecahkan `core.js` kepada 11 utiliti modular.
- Menambah enjin tapisan seragam untuk tahun, tahap, kelas, mata pelajaran, murid dan TP.
- Menambah agihan peratus TP tanpa purata TP.
- Menambah ringkasan, metadata dan formatter yang boleh diguna semula.
- Mengekalkan `PBDAnalysisCore` sebagai lapisan keserasian untuk semua modul Sprint 1.
- Menambah ujian Core Framework.

## v2.1 — Sprint 1

- Analysis Engine modular: sekolah, tahap, tahun, kelas, mata pelajaran dan murid.
