# SAP-TEMIN v2.1.5 — Sprint 1.5 Core Framework

Versi ini memecahkan fungsi asas analisis kepada utiliti modular yang boleh digunakan semula oleh modul PBD dan modul akan datang seperti UASA, SEGAK, Kehadiran dan Disiplin.

## Struktur teras

- `constants.js` — tetapan TP dan tahap
- `formatter.js` — normalisasi dan paparan nilai
- `validation.js` — semakan input
- `collections.js` — unique, sorting dan grouping
- `records.js` — menukar data import kepada rekod standard
- `students.js` — kiraan dan senarai murid unik
- `distribution.js` — agihan TP dan butiran klik
- `mastery.js` — Menguasai / Belum Menguasai
- `statistics.js` — ringkasan umum
- `filters.js` — tapisan dan pilihan dropdown
- `metadata.js` — maklumat import

`js/analysis/core.js` kekal sebagai pintu keserasian supaya modul Sprint 1 terus berjalan tanpa perubahan besar.

## Prinsip kekal

- Tiada purata TP.
- Tiada ranking TP.
- TP1–TP2: Belum Menguasai.
- TP3–TP6: Menguasai.
- Kiraan rekod dan murid unik dibezakan.
- Data diproses dalam pelayar pengguna.

## Ujian

Jalankan:

```bash
node tests/core-utilities.test.js
node tests/analysis-engine.test.js
```
